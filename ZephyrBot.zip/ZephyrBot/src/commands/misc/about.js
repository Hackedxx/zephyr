const { PermissionsBitField, EmbedBuilder } = require("discord.js");

module.exports = {
  name: "about",
  description: "⁉ Gives information about the bot!",
  deleted: Boolean,
};
