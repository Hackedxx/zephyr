require("dotenv").config();
const {
  Client,
  IntentsBitField,
  EmbedBuilder,
  ActivityType,
  Activity,
} = require("discord.js");
const eventHandler = require("./handlers/eventHandler");

const client = new Client({
  intents: [
    IntentsBitField.Flags.Guilds,
    IntentsBitField.Flags.GuildMembers,
    IntentsBitField.Flags.GuildMessages,
    IntentsBitField.Flags.MessageContent,
  ],
});

client.on("messageCreate", (message) => {
  if (message.author.bot) {
    return;
  }

  if (message.content === "!about") {
    const aboutEmbed = new EmbedBuilder()
      .setColor(0x70178b)
      .setTitle("About Zephyr ↯")
      .setDescription(
        "Zephyr is a fully fledged **free** discord bot which offers many features which are equivalent to Dyno, MEE6, Arcane etc.. Feel free to use our bot! [website](http://zephyrbot.000.pe)"
      )
      .setTimestamp()
      .setFooter({
        text: "made with <3 by hackqd. enjoy ✌",
        iconURL: "https://t.ly/ZX5Wl",
      });

    message.channel.send({ content: "!about", embeds: [aboutEmbed] });
  }
});

eventHandler(client);

client.login(process.env.TOKEN);
